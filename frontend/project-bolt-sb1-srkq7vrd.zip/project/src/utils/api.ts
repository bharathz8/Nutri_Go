export const API_BASE_URL = 'http://localhost:8000';

export const apiRequest = async (endpoint: string, options?: RequestInit) => {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  });

  if (!response.ok) {
    throw new Error(`API request failed: ${response.status}`);
  }

  return response.json();
};

// Translation utility function
export const translateText = async (text: string, targetLanguage: string) => {
  try {
    const response = await fetch(`${API_BASE_URL}/translate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        text: text,
        target_language: targetLanguage
      })
    });

    if (response.ok) {
      const data = await response.json();
      return data.translated_text;
    } else {
      console.error('Translation failed:', response.status);
      return text; // Return original text if translation fails
    }
  } catch (error) {
    console.error('Translation error:', error);
    return text; // Return original text if translation fails
  }
};

// Get supported languages
export const getSupportedLanguages = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/languages`);
    if (response.ok) {
      const data = await response.json();
      return data.supported_languages;
    }
    return {};
  } catch (error) {
    console.error('Failed to fetch supported languages:', error);
    return {};
  }
};