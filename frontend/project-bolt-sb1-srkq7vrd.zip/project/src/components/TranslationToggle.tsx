import React, { useState, useEffect } from 'react';
import { Languages, Loader } from 'lucide-react';
import { translateText, getSupportedLanguages } from '../utils/api';

interface TranslationToggleProps {
  text: string;
  currentLanguage: string;
  onTranslatedText: (translatedText: string, language: string) => void;
  className?: string;
}

const TranslationToggle: React.FC<TranslationToggleProps> = ({
  text,
  currentLanguage,
  onTranslatedText,
  className = ""
}) => {
  const [isTranslating, setIsTranslating] = useState(false);
  const [supportedLanguages, setSupportedLanguages] = useState<Record<string, string>>({});
  const [showLanguageMenu, setShowLanguageMenu] = useState(false);

  const languages = [
    { code: 'english', name: 'English', native: 'English' },
    { code: 'hindi', name: 'Hindi', native: 'हिंदी' },
    { code: 'tamil', name: 'Tamil', native: 'தமிழ்' },
    { code: 'telugu', name: 'Telugu', native: 'తెలుగు' },
    { code: 'kannada', name: 'Kannada', native: 'ಕನ್ನಡ' },
    { code: 'malayalam', name: 'Malayalam', native: 'മലയാളം' },
    { code: 'bengali', name: 'Bengali', native: 'বাংলা' },
    { code: 'gujarati', name: 'Gujarati', native: 'ગુજરાતી' },
    { code: 'marathi', name: 'Marathi', native: 'मराठी' },
    { code: 'punjabi', name: 'Punjabi', native: 'ਪੰਜਾਬੀ' }
  ];

  useEffect(() => {
    const fetchLanguages = async () => {
      const langs = await getSupportedLanguages();
      setSupportedLanguages(langs);
    };
    fetchLanguages();
  }, []);

  const handleTranslate = async (targetLanguage: string) => {
    if (targetLanguage === currentLanguage || !text.trim()) {
      setShowLanguageMenu(false);
      return;
    }

    setIsTranslating(true);
    setShowLanguageMenu(false);

    try {
      const translatedText = await translateText(text, targetLanguage);
      onTranslatedText(translatedText, targetLanguage);
    } catch (error) {
      console.error('Translation failed:', error);
    } finally {
      setIsTranslating(false);
    }
  };

  const getCurrentLanguageName = () => {
    const lang = languages.find(l => l.code === currentLanguage);
    return lang ? lang.native : 'English';
  };

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => setShowLanguageMenu(!showLanguageMenu)}
        disabled={isTranslating}
        className="flex items-center space-x-2 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
      >
        {isTranslating ? (
          <Loader className="w-4 h-4 animate-spin text-emerald-600" />
        ) : (
          <Languages className="w-4 h-4 text-emerald-600" />
        )}
        <span className="text-sm font-medium text-gray-700">
          {getCurrentLanguageName()}
        </span>
      </button>

      {showLanguageMenu && (
        <div className="absolute top-full left-0 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-50 max-h-64 overflow-y-auto">
          {languages.map((language) => (
            <button
              key={language.code}
              onClick={() => handleTranslate(language.code)}
              className={`w-full text-left px-4 py-3 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-b-0 ${
                currentLanguage === language.code ? 'bg-emerald-50 text-emerald-700' : 'text-gray-700'
              }`}
            >
              <div className="flex flex-col">
                <span className="font-medium">{language.native}</span>
                <span className="text-xs text-gray-500">{language.name}</span>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default TranslationToggle;